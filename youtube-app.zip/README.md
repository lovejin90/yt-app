# Python Project

이 프로젝트는 파이썬으로 작성된 기본 프로젝트입니다.

## 설치 방법

1. 가상환경 생성 및 활성화:

```bash
python -m venv venv
source venv/bin/activate  # macOS/Linux
```

2. 필요한 패키지 설치:

```bash
pip install -r requirements.txt
```

## 실행 방법

```bash
python main.py
```

## 개발 도구

- Python 3.x
- pytest: 테스트
- black: 코드 포맷팅
- flake8: 코드 린팅
